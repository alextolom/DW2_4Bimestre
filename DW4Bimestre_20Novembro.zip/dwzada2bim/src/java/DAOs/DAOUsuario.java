package DAOs;

import Entidades.Usuario;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAOUsuario extends DAOGenerico<Usuario> {

    public DAOUsuario() {
        super(Usuario.class);
    }


//    public boolean validate(Usuario usuario) throws ClassNotFoundException {
//        boolean status = false;
//
//        Class.forName("com.mysql.jdbc.Driver");
//
//        try (Connection connection = DriverManager
//            .getConnection("jdbc:mysql://localhost:3306/orangeweb", "root", "");
//
//            // Step 2:Create a statement using connection object
//            PreparedStatement preparedStatement = connection
//            .prepareStatement("select * from usuario where usernameUsuario = ? and passwordUsuario = ? ")) {
//            preparedStatement.setString(1, usuario.getUsernameUsuario());
//            preparedStatement.setString(2, usuario.getPasswordUsuario());
//
//            System.out.println(preparedStatement);
//            ResultSet rs = preparedStatement.executeQuery();
//            status = rs.next();
//
//        } catch (SQLException e) {
//            // process sql exception
//            printSQLException(e);
//        }
//        return status;
//    }
//
//    private void printSQLException(SQLException ex) {
//        for (Throwable e: ex) {
//            if (e instanceof SQLException) {
//                e.printStackTrace(System.err);
//                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
//                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
//                System.err.println("Message: " + e.getMessage());
//                Throwable t = ex.getCause();
//                while (t != null) {
//                    System.out.println("Cause: " + t);
//                    t = t.getCause();
//                }
//            }
//        }
//    }    
    
    
    public int autoIdUsuario() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idUsuario) FROM Usuario e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Usuario> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Usuario e WHERE e.nomeUsuario LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Usuario> listById(int id) {
        return em.createQuery("SELECT e FROM Usuario e WHERE e.idUsuario = :id").setParameter("id", id).getResultList();
    }

    public List<Usuario> listInOrderNome() {
        return em.createQuery("SELECT e FROM Usuario e ORDER BY e.nomeUsuario").getResultList();
    }

    public List<Usuario> listInOrderId() {
        return em.createQuery("SELECT e FROM Usuario e ORDER BY e.idUsuario").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Usuario> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdUsuario() + "-" + lf.get(i).getUsernameUsuario());
        }
        return ls;
    }
}
